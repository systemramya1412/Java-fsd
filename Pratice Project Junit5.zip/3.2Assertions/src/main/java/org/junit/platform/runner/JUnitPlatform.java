package org.junit.platform.runner;

public class JUnitPlatform {

}
