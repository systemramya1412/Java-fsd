package coms.RestFulServiceWithJpaApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestFulServiceWithJpaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
