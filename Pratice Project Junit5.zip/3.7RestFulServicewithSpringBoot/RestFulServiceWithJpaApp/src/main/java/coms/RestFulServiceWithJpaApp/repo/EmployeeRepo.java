package coms.RestFulServiceWithJpaApp.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import coms.RestFulServiceWithJpaApp.Entities.Employee;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

	//HQL : Query
	@Query(nativeQuery=true, value="select e.* from Employee  e where e.email =:email  and e.pswd=:pwd")
	public Optional<Employee> EmpUserCheck(@Param("email") String email, @Param("pwd") String pswd);
}
