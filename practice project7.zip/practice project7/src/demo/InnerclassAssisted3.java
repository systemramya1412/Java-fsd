package demo;

public class InnerclassAssisted3 {
	

		public static void main(String[] args) {
		InnerclassAssisted3 i = new InnerclassAssisted3() {

		         public void display() {
		            System.out.println("Anonymous Inner Class");
		         }
		      };
		      
		   }
		}








