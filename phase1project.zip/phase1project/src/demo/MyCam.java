package demo;

import java.util.ArrayList;
public class MyCam {
	public static ArrayList<Camera> myCamera = new ArrayList<>();

}



