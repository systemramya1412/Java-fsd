package com;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class ElementLocator {
    public static void main(String[] args) {
        // Set the path of ChromeDriver
    	System.setProperty("webdriver.edge.driver", "C:\\Users\\hp\\Downloads\\edgedriver_win64\\msedgedriver.exe");

        WebDriver driver = new EdgeDriver();
        driver.get("http://www.google.com/");

      
				driver.findElement(By.cssSelector("input#email"));
				
				// b. Tag and Class
				driver.findElement(By.cssSelector("input.inputtext"));
				
				// c. Tag and Attribute
				driver.findElement(By.cssSelector("input[name=lastName]"));
				
				// d. Inner text
				driver.findElement(By.cssSelector("font:contains('Boston')"));
				
				// Step 1.3.2: To find the element present on the page using XPath
				// a. Absolute XPath
				driver.findElement(By.xpath("html/body/div[1]/div[1]/div/h4[1]/b"));
				
				// b. Relative XPath
				driver.findElement(By.xpath("//*[@class='relativexapath']"));
				
				
				driver.quit();
    }
        
}
