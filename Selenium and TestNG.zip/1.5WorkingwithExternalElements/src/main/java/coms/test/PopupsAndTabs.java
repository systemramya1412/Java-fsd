package coms.test;



	import org.openqa.selenium.By;
		import org.openqa.selenium.WebDriver;
		import org.openqa.selenium.WebElement;
		import org.openqa.selenium.chrome.ChromeDriver;

		public class PopupsAndTabs {

			public static void main(String[] args) throws Exception {
				WebDriver driver = new ChromeDriver();
				driver.manage().window().maximize();
				
				driver.get("file:///C:/Tricon/MyHtmlRepo/Second.html");
				Thread.sleep(3000);
				
				// Alert() Method
				WebElement btn1 = driver.findElement(By.cssSelector("input[value='Alert Box Button']"));
				btn1.click();
				Thread.sleep(3000);
				String str = driver.switchTo().alert().getText();
				Thread.sleep(3000);
				driver.switchTo().alert().accept();
				Thread.sleep(3000);
				System.out.println("AlertBox Text : " + str);
				Thread.sleep(3000);
				// Confirm() Method
				WebElement cbtn1 = driver.findElement(By.cssSelector("input[value='Confirm Box Button']"));
				cbtn1.click();
				Thread.sleep(3000);
				String cstr = driver.switchTo().alert().getText();
				Thread.sleep(3000);
				System.out.println("Confirm Box Text : " + cstr);
				driver.switchTo().alert().accept(); // OK button
				String info = driver.findElement(By.id("res")).getText();
				System.out.println(info);
				
				Thread.sleep(3000);
				cbtn1 = driver.findElement(By.cssSelector("input[value='Confirm Box Button']"));
				cbtn1.click();
				Thread.sleep(3000);
				driver.switchTo().alert().dismiss(); // Cancel button
				info = driver.findElement(By.id("res")).getText();
				System.out.println(info);
				Thread.sleep(3000);
				
				// Prompt() method
				
				WebElement btn3 = driver.findElement(By.cssSelector("input[value='Prompt Box Button']"));
				btn3.click();
				Thread.sleep(3000);
				driver.switchTo().alert().sendKeys("Pavan Kumar");
				Thread.sleep(3000);
				driver.switchTo().alert().accept();
				info = driver.findElement(By.id("res")).getText();
				System.out.println("Given Name is : " + info);
				
				Thread.sleep(3000);
				
				btn3 = driver.findElement(By.cssSelector("input[value='Prompt Box Button']"));
				btn3.click();
				Thread.sleep(3000);
				driver.switchTo().alert().sendKeys("Pavan Kumar");
				Thread.sleep(3000);
				driver.switchTo().alert().dismiss();
				info = driver.findElement(By.id("res")).getText();
				System.out.println("Given Name is : " + info);
				
				Thread.sleep(3000);
				driver.quit();
			}
		

	}


