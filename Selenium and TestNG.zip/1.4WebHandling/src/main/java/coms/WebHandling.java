package coms;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class WebHandling {

    public static void main(String[] args) {
        // Setting up Chrome driver path
    	System.setProperty("webdriver.edge.driver", "C:\\Users\\hp\\Downloads\\edgedriver_win64\\msedgedriver.exe");

        WebDriver driver = new EdgeDriver();
        driver.get("http://www.google.com/");
        
        // Implicit wait to handle dynamic elements
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        // Step 1.4.1: Handling Edit box
        driver.get("url_to_your_page");
        WebElement editBox = driver.findElement(By.id("editBoxId"));
        editBox.sendKeys("Text to enter");
        String valueEntered = editBox.getAttribute("value");
        System.out.println("Value entered in edit box: " + valueEntered);
        editBox.clear();

        // Step 1.4.2: Handling Link
        WebElement link = driver.findElement(By.linkText("Link Text"));
        link.click();

        // Step 1.4.3: Handling Button
        WebElement button = driver.findElement(By.id("buttonId"));
        button.click();
        boolean isEnabled = button.isEnabled();
        System.out.println("Button enabled status: " + isEnabled);
        boolean isDisplayed = button.isDisplayed();
        System.out.println("Button displayed status: " + isDisplayed);

        // Step 1.4.4: Handling Image, Image Link, Image Button
        WebElement image = driver.findElement(By.id("imageId"));
        image.click();

        // Step 1.4.5: Handling Text area
        WebElement textArea = driver.findElement(By.id("textAreaId"));
        String text = textArea.getText();
        System.out.println("Text in text area: " + text);

        // Step 1.4.6: Handling Checkbox
        WebElement checkbox = driver.findElement(By.id("checkboxId"));
        checkbox.click();
        boolean isSelected = checkbox.isSelected();
        System.out.println("Checkbox selected status: " + isSelected);

        // Step 1.4.7: Handling Radio button
        WebElement radioButton = driver.findElement(By.id("radioButtonId"));
        radioButton.click();
        isSelected = radioButton.isSelected();
        System.out.println("Radio button selected status: " + isSelected);

        // Step 1.4.8: Handling Dropdown list
        Select dropdown = new Select(driver.findElement(By.id("dropdownId")));
        dropdown.selectByVisibleText("Option 1");
        int itemCount = dropdown.getOptions().size();
        System.out.println("Dropdown items count: " + itemCount);

        // Step 1.4.9: Handling Web table /HTML table
        WebElement table = driver.findElement(By.tagName("table"));
        int rowsCount = table.findElements(By.tagName("tr")).size();
        int cellsCount = table.findElements(By.tagName("td")).size();
        System.out.println("Rows count: " + rowsCount);
        System.out.println("Cells count: " + cellsCount);

        // Step 1.4.10: Handling Frame
        driver.switchTo().frame("frameName");

        // Step 1.4.11: Handling Switching between tabs in the same browser window
        String oldTab = driver.getWindowHandle();
        driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");        ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(newTab.get(1));
        // Perform operations in the new tab
        driver.switchTo().window(oldTab);

        // Close the browser
        driver.quit();
    }
}



