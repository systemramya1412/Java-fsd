package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class TestApp4 {

    public static void main(String[] args) throws InterruptedException {
        // Set the path to the Microsoft Edge WebDriver executable
        System.setProperty("webdriver.edge.driver", "C:\\Users\\hp\\Downloads\\edgedriver_win64\\msedgedriver.exe");

        WebDriver driver = new EdgeDriver();
        driver.get("http://www.google.com/");
        driver.get("http://www.facebook.com/");
		Thread.sleep(2000);
		WebElement web = driver.findElement(By.cssSelector("input[type='text']"));
		web.sendKeys("ramya@gmail.com");
		Thread.sleep(2000);
		web = driver.findElement(By.cssSelector("input[type='password']"));
		web.sendKeys("Ram@1234");
		Thread.sleep(2000);
		web =driver.findElement(By.name("login"));
		web.submit();
		
		Thread.sleep(2000);
		driver.close();
	}
   

    }
