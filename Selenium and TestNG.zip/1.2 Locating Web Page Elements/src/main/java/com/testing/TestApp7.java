package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class TestApp7 {

    public static void main(String[] args) {
        // Set the path to the Microsoft Edge WebDriver executable
        System.setProperty("webdriver.edge.driver", "C:\\Users\\hp\\Downloads\\edgedriver_win64\\msedgedriver.exe");

        WebDriver driver = new EdgeDriver();
        driver.get("http://www.google.com/");
     WebElement web = driver.findElement(By.name("q"));
		
		web.sendKeys("Seven Wonders of the world");
		web.submit();
	}
   

    }
