package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class TestApp3 {

    public static void main(String[] args) {
        // Set the path to the Microsoft Edge WebDriver executable
        System.setProperty("webdriver.edge.driver", "C:\\Users\\hp\\Downloads\\edgedriver_win64\\msedgedriver.exe");

        WebDriver driver = new EdgeDriver();
        driver.get("http://www.facebook.com/");
	
		driver.findElement(By.name("email")).sendKeys("ramya@gmail.com");
		
		driver.findElement(By.name("pass")).sendKeys("Ram@123");
	
		driver.findElement(By.name("login")).submit();
	}
	}
   

