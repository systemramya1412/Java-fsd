package demo;
import java.io.File;
import java.io.IOException;

public class CreateNewFile {
    public static void main(String[] args) {
        // Specify the file path
        String filePath = "example2.txt";

        try {
            // Create a File object
            File file = new File(filePath);

            // Check if the file already exists
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getAbsolutePath());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            // Handle IOException (e.g., if there is an issue creating the file)
            System.err.println("Error creating the file: " + e.getMessage());
        }
    }
}
