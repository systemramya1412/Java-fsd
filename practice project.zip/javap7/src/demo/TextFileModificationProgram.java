package demo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TextFileModificationProgram {
    public static void main(String[] args) {
        // Specify the file path
        String filePath = "example.txt";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            // Append additional text to the file
            writer.write("\nThis is an updated line.");

            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.err.println("Error updating the file: " + e.getMessage());
        }
    }
}



