package pack1;

public class ProaccessSpecfiers {

		// TODO Auto-generated method stub
		protected void display() 
	    { 
	        System.out.println("This is protected access specifier"); 
	    } 
	


	}

