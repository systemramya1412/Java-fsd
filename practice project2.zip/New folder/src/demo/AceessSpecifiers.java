package demo;

public class AceessSpecifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
